.. include:: ../../CONTRIBUTING.rst
