.. _contents:

************************
PyGraphviz documentation
************************

.. only:: html

    :Release: |version|
    :Date: |today|

.. toctree::
   :maxdepth: 2


   install
   tutorial
   auto_examples/index
   reference/index
   contribute
